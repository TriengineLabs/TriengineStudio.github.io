function home(){

	 window.location="/";

}

function proj() {

	window.location="../../pages/projects/projects.html"
}

function news() {

	window.location="../../pages/news/news.html"
}

//for index.html
function home_ind(){

	 window.location="/";

}

function proj_ind() {

	window.location="pages/projects/projects.html"
}

function news_ind() {

	window.location="pages/news/news.html"
}